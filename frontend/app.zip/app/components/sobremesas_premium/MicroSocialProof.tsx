"use client";

import React from "react";
import { FaUsers, FaStar, FaCheckCircle, FaShoppingCart } from "react-icons/fa";

const MicroSocialProof: React.FC = () => {
  return (
    <section className="py-6 sm:py-8 px-4 bg-white border-y border-gray-100">
      <div className="max-w-5xl mx-auto">
        {/* Grid de métricas */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6">
          {/* Métrica 1 */}
          <div className="flex flex-col items-center text-center p-3 rounded-xl bg-gradient-to-br from-pink-50 to-rose-50">
            <FaUsers className="text-2xl sm:text-3xl text-pink-500 mb-2" />
            <p className="text-xl sm:text-2xl font-bold text-gray-900">+1.000</p>
            <p className="text-xs sm:text-sm text-gray-600">clientes satisfeitos</p>
          </div>

          {/* Métrica 2 */}
          <div className="flex flex-col items-center text-center p-3 rounded-xl bg-gradient-to-br from-yellow-50 to-amber-50">
            <FaStar className="text-2xl sm:text-3xl text-yellow-500 mb-2" />
            <p className="text-xl sm:text-2xl font-bold text-gray-900">4.9/5</p>
            <p className="text-xs sm:text-sm text-gray-600">avaliação média</p>
          </div>

          {/* Métrica 3 */}
          <div className="flex flex-col items-center text-center p-3 rounded-xl bg-gradient-to-br from-green-50 to-emerald-50">
            <FaCheckCircle className="text-2xl sm:text-3xl text-green-500 mb-2" />
            <p className="text-xl sm:text-2xl font-bold text-gray-900">+50</p>
            <p className="text-xs sm:text-sm text-gray-600">receitas funcionais</p>
          </div>

          {/* Métrica 4 */}
          <div className="flex flex-col items-center text-center p-3 rounded-xl bg-gradient-to-br from-purple-50 to-violet-50">
            <FaShoppingCart className="text-2xl sm:text-3xl text-purple-500 mb-2" />
            <p className="text-xl sm:text-2xl font-bold text-gray-900">62%</p>
            <p className="text-xs sm:text-sm text-gray-600">de desconto hoje</p>
          </div>
        </div>

        {/* Faixa de urgência sutil */}
        <div className="mt-6 text-center">
          <p className="inline-flex items-center gap-2 text-sm text-gray-600 bg-amber-50 px-4 py-2 rounded-full">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
            </span>
            <span>
              <strong className="text-amber-700">23 pessoas</strong> estão vendo esta página agora
            </span>
          </p>
        </div>
      </div>
    </section>
  );
};

export default MicroSocialProof;
