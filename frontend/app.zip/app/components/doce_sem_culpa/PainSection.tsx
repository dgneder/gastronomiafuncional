"use client";
import React from "react";

const pains = [
  { emoji: "😔", title: "Você quer sobremesa — mas sente culpa antes mesmo de provar", text: "Essa culpa não é fraqueza. É o resultado de anos ouvindo que doce é errado. O problema nunca foi a sobremesa — foi o que colocaram dentro dela." },
  { emoji: "🧁", title: "Já tentou receitas 'fit' da internet que tinham gosto de dieta", text: "Seco, sem sabor, textura estranha. A conclusão inevitável: 'saudável não pode ser gostoso'. Essa conclusão está errada — e vamos provar receita por receita." },
  { emoji: "💊", title: "Tem restrição alimentar e sente que sobremesa não é para você", text: "Sem glúten, sem lactose, diabético, renal — a mesa de sobremesas parece um campo minado. A ciência já sabe como navegar nele com prazer e segurança." },
  { emoji: "🔬", title: "Ninguém explica o porquê — só diz 'troca açúcar por adoçante'", text: "Substituições sem entender a função de cada ingrediente resultam em sobremesas que derretem, não cremificam e não satisfazem. A ciência muda isso completamente." },
];

const PainSection: React.FC = () => (
  <section className="py-20 px-6 lg:px-12 bg-white" data-aos="fade-up">
    <div className="max-w-5xl mx-auto">
      <div className="text-center mb-14">
        <p className="text-sm uppercase tracking-widest font-semibold mb-3" style={{ color: "#8B2252" }}>Você se identifica?</p>
        <h2 className="text-3xl lg:text-4xl font-extrabold text-gray-900 leading-tight">
          Se a sobremesa virou seu inimigo,<br />
          <span style={{ color: "#8B2252" }}>o problema não é a sobremesa.</span>
        </h2>
        <p className="mt-4 text-lg text-gray-500 max-w-2xl mx-auto">É o que ninguém te ensinou sobre como fazê-la diferente.</p>
      </div>
      <div className="grid gap-6 md:grid-cols-2">
        {pains.map((pain, i) => (
          <div key={i} data-aos="fade-up" data-aos-delay={i * 100}
            className="group p-7 rounded-2xl border border-rose-100 bg-rose-50/30 hover:shadow-lg hover:border-rose-200 transition-all duration-300">
            <div className="flex items-start gap-4">
              <span className="text-3xl shrink-0 mt-1">{pain.emoji}</span>
              <div>
                <h3 className="text-lg font-bold text-gray-800 mb-2 group-hover:text-rose-800 transition-colors">{pain.title}</h3>
                <p className="text-gray-500 leading-relaxed text-[15px]">{pain.text}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-16 text-center" data-aos="fade-up">
        <div className="inline-flex items-center gap-3 px-8 py-4 rounded-2xl border" style={{ backgroundColor: "#8B225208", borderColor: "#8B225225" }}>
          <span className="text-2xl">👇</span>
          <p className="font-semibold text-lg" style={{ color: "#8B2252" }}>Existe um caminho com ciência, receitas testadas e prazer de verdade.</p>
        </div>
      </div>
    </div>
  </section>
);

export default PainSection;
