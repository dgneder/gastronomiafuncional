"use client";

import Image from "next/image";
import React from "react";
import { FaArrowRight, FaLock, FaCreditCard, FaShieldAlt, FaStar } from "react-icons/fa";
import { MdOutlineCake } from "react-icons/md";

interface HeroProps {
  onButtonClick: () => void;
}

const anchors = [
  { icon: "🏷️", label: "De R$97 por R$47",         sub: "52% OFF · lançamento"       },
  { icon: "📚", label: "+500 receitas",              sub: "3 volumes completos"         },
  { icon: "🔒", label: "Hotmart",                   sub: "Pagamento seguro"            },
  { icon: "🛡️", label: "Garantia 7 dias",           sub: "Acesso imediato"             },
];

function MockupStrip() {
  return (
    <div
      className="flex items-center gap-5 rounded-2xl p-5 border shadow-sm"
      style={{ background: "linear-gradient(135deg, #FFF0F5, #FCEEF4)", borderColor: "#8B225220" }}
    >
      <div className="relative w-20 h-28 lg:w-24 lg:h-32 rounded-xl overflow-hidden shadow-lg border-2 border-white shrink-0">
        <Image
          src="/sobremesas/sobremesas-hero.png"
          alt="Mockup Doce Sem Culpa"
          fill
          className="object-cover"
        />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs font-bold uppercase tracking-widest mb-2" style={{ color: "#8B2252" }}>
          O que você recebe
        </p>
        <ul className="space-y-1">
          {[
            "Volume 1 — 150 Sobremesas Funcionais",
            "Volume 2 — 252 receitas com ciência",
            "Volume 3 — 100 Trufas & Docinhos",
            "Sistema de tags por restrição alimentar",
          ].map((item, i) => (
            <li key={i} className="flex items-center gap-2 text-gray-600">
              <span
                className="w-4 h-4 rounded-full flex items-center justify-center shrink-0 text-white text-[9px]"
                style={{ backgroundColor: "#8B2252" }}
              >
                ✓
              </span>
              <span className="text-[13px]">{item}</span>
            </li>
          ))}
        </ul>
        <div className="flex items-baseline gap-2 mt-3 pt-3" style={{ borderTop: "1px solid #8B225215" }}>
          <span className="text-gray-400 line-through text-sm">R$97</span>
          <span className="text-2xl font-extrabold" style={{ color: "#8B2252" }}>R$47</span>
          <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-green-50 text-green-700 border border-green-200">lançamento</span>
        </div>
      </div>
    </div>
  );
}

const Hero: React.FC<HeroProps> = ({ onButtonClick }) => {
  return (
    <section
      id="hero"
      className="relative pt-6 pb-12 lg:py-20"
      style={{ background: "linear-gradient(160deg, #FFF0F5 0%, #FCEEF4 40%, #FFF8F0 70%, #FFF0F5 100%)" }}
    >
      {/* Barra decorativa topo */}
      <div className="absolute top-0 left-0 right-0 h-1" style={{ background: "linear-gradient(90deg, #8B2252, #D4A04A, #8B2252)" }} />

      {/* Decoração fundo */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-32 -right-32 w-96 h-96 rounded-full opacity-10" style={{ background: "radial-gradient(circle, #8B2252, transparent)" }} />
        <div className="absolute -bottom-32 -left-32 w-96 h-96 rounded-full opacity-10" style={{ background: "radial-gradient(circle, #D4A04A, transparent)" }} />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-6 lg:px-12">
        <div className="flex flex-col lg:flex-row lg:items-center lg:gap-14">

          {/* Coluna texto */}
          <div className="lg:w-1/2">
            {/* Badge prova social */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-white/90 rounded-full shadow-sm mb-4 border border-rose-100">
              <div className="flex gap-0.5">
                {[...Array(5)].map((_, i) => <FaStar key={i} className="text-amber-400 text-xs" />)}
              </div>
              <span className="text-xs font-semibold text-gray-700">4.9 · +2.000 vendas · Pixel maduro</span>
            </div>

            {/* Eyebrow */}
            <p className="text-sm uppercase tracking-widest font-bold mb-3" style={{ color: "#8B2252" }}>
              A Coleção Completa de Sobremesas Funcionais
            </p>

            {/* Headline */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-gray-900 leading-[1.1] mb-4">
              +500 sobremesas{" "}
              <span style={{ color: "#8B2252" }}>com ciência</span>{" "}
              e{" "}
              <span style={{ color: "#D4A04A" }}>muito sabor</span>
            </h1>

            <p className="text-base sm:text-lg text-gray-500 mb-6 max-w-lg leading-relaxed">
              Três volumes, uma missão: provar que sobremesa funcional pode ser bonita,
              gostosa e respaldada pela ciência. De mousses a trufas, de bolos a brigadeiros
              — sem abrir mão do prazer.
            </p>

            {/* Mockup strip */}
            <MockupStrip />

            {/* CTA */}
            <div className="mt-6">
              <button
                onClick={onButtonClick}
                className="group w-full sm:w-auto px-10 py-5 text-lg font-bold text-white rounded-xl shadow-xl hover:shadow-2xl hover:scale-[1.03] active:scale-[0.98] transition-all duration-300 flex items-center justify-center gap-3"
                style={{ background: "linear-gradient(135deg, #8B2252, #6B1A40)" }}
              >
                <MdOutlineCake className="text-xl" />
                Garantir Meu Acesso por R$47
                <FaArrowRight className="group-hover:translate-x-1 transition-transform" />
              </button>
              <div className="flex flex-wrap gap-4 mt-3 text-xs text-gray-400">
                <span className="flex items-center gap-1"><FaLock className="text-green-500" /> Hotmart · Seguro</span>
                <span className="flex items-center gap-1"><FaCreditCard /> PIX · Cartão · Boleto</span>
                <span className="flex items-center gap-1"><FaShieldAlt className="text-green-500" /> 7 dias de garantia</span>
              </div>
            </div>
          </div>

          {/* Coluna direita — imagem + anchors */}
          <div className="lg:w-1/2 mt-10 lg:mt-0">
            {/* Imagem hero */}
            <div className="relative w-full aspect-[4/3] rounded-3xl overflow-hidden shadow-2xl border-4 border-white mb-6">
              <Image
                src="/sobremesas/sobremesas-hero.png"
                alt="Coleção Doce Sem Culpa"
                fill
                className="object-cover"
                priority
              />
              <div className="absolute -bottom-4 -right-4 bg-white rounded-2xl shadow-xl px-4 py-3 border border-rose-100">
                <p className="text-xs font-bold uppercase tracking-wide" style={{ color: "#8B2252" }}>3 volumes</p>
                <p className="text-2xl font-black text-gray-900">+500</p>
                <p className="text-xs text-gray-400">receitas funcionais</p>
              </div>
            </div>

            {/* Anchor badges */}
            <div className="grid grid-cols-2 gap-3">
              {anchors.map((a, i) => (
                <div key={i} className="bg-white/80 rounded-xl px-4 py-3 shadow-sm border border-rose-50 flex items-center gap-3">
                  <span className="text-xl">{a.icon}</span>
                  <div>
                    <p className="text-xs font-bold text-gray-800">{a.label}</p>
                    <p className="text-[11px] text-gray-400">{a.sub}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
