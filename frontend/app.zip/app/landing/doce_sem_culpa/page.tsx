"use client";

/**
 * DOCE SEM CULPA — Landing Page
 * Rota: app/landing/doce_sem_culpa/page.tsx
 *
 * Substitua HOTMART_CHECKOUT_URL pelo link real do produto Hotmart.
 * Pixel: AddToCart + InitiateCheckout disparados no clique (sem página intermediária).
 */

import React, { useEffect, useCallback } from "react";
import dynamic from "next/dynamic";

import LGPD             from "@/app/components/doce_sem_culpa/LGPD";
import FloatingNavBar   from "@/app/components/doce_sem_culpa/FloatingNavBar";
import CountdownBanner  from "@/app/components/doce_sem_culpa/CountdownBanner";
import { useTracking }  from "@/app/hooks/useTracking";

// Componentes above-the-fold — carregamento imediato
import Hero from "@/app/components/doce_sem_culpa/Hero";

// Componentes below-the-fold — lazy load
const PainSection         = dynamic(() => import("@/app/components/doce_sem_culpa/PainSection"));
const AuthoritySection    = dynamic(() => import("@/app/components/doce_sem_culpa/AuthoritySection"));
const TransformationSection = dynamic(() => import("@/app/components/doce_sem_culpa/TransformationSection"));
const RecipeShowcase      = dynamic(() => import("@/app/components/doce_sem_culpa/RecipeShowcase"));
const CTASection          = dynamic(() => import("@/app/components/doce_sem_culpa/CTASection"));
const CourseContent       = dynamic(() => import("@/app/components/doce_sem_culpa/CourseContent"));
const TagsSystem          = dynamic(() => import("@/app/components/doce_sem_culpa/TagsSystem"));
const BonusSection        = dynamic(() => import("@/app/components/doce_sem_culpa/BonusSection"));
const SocialProofSection  = dynamic(() => import("@/app/components/doce_sem_culpa/SocialProofSection"));
const FAQ                 = dynamic(() => import("@/app/components/doce_sem_culpa/FAQ"));
const Guarantee           = dynamic(() => import("@/app/components/doce_sem_culpa/Guarantee"));
const FinalCTA            = dynamic(() => import("@/app/components/doce_sem_culpa/FinalCTA"));
const Footer              = dynamic(() => import("@/app/components/doce_sem_culpa/Footer"));

// Vídeos — ssr: false obrigatório
const VideoSection = dynamic(() => import("@/app/components/doce_sem_culpa/VideoSection"), { ssr: false });
const VideoWall    = dynamic(() => import("@/app/components/doce_sem_culpa/VideoWall"),    { ssr: false });

// ─── CONFIG ──────────────────────────────────────────────────────────────────
const HOTMART_CHECKOUT_URL = "https://pay.hotmart.com/SEU_LINK_AQUI?checkoutMode=10";

// ─── PAGE ────────────────────────────────────────────────────────────────────
const DoceSemCulpaPage: React.FC = () => {
  const { trackViewContent, trackAddToCart, trackInitiateCheckout } = useTracking() as {
    trackViewContent?:      (name: string, id: string, value: number) => void;
    trackAddToCart?:        (name: string, id: string, value: number) => void;
    trackInitiateCheckout?: (name: string, id: string, value: number) => void;
  };

  // ViewContent na montagem da página
  useEffect(() => {
    trackViewContent?.("Doce Sem Culpa — Coleção Completa", "doce-sem-culpa", 47.00);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // CTA handler: dispara AddToCart + InitiateCheckout antes do redirect
  const handleButtonClick = useCallback(() => {
    trackAddToCart?.("Doce Sem Culpa — Coleção Completa", "doce-sem-culpa", 47.00);
    trackInitiateCheckout?.("Doce Sem Culpa — Coleção Completa", "doce-sem-culpa", 47.00);
    window.location.href = HOTMART_CHECKOUT_URL;
  }, [trackAddToCart, trackInitiateCheckout]);

  const handleLoginClick = () => {
    window.location.href = "https://gastronomia-funcional.memberkit.com.br/";
  };

  return (
    <div className="overflow-x-hidden">
      {/* Elementos fixos */}
      <FloatingNavBar onLoginClick={handleLoginClick} handleButtonClick={handleButtonClick} />
      <CountdownBanner />
      <LGPD />

      {/* Hero — acima da dobra */}
      <Hero onButtonClick={handleButtonClick} />

      {/* Vídeo 1 — prova visual imediata logo após o Hero */}
      <VideoSection
        variant="split-right"
        tag="Receita do Volume 1"
        headline="Pronto em 15 minutos. No liquidificador. Agora."
        subtext="O mousse de cacau funcional é a porta de entrada da coleção. Sem forno, sem equipamento especial. Cacau 70%, abacate e mel — ciência e sabor na mesma taça."
        videoSrc="/sobremesas/videos/video_01.webm"
        poster="/sobremesas/gallery/mousse.jpg"
        caption="Mousse de Cacau com Abacate · SG · SA · LC · ANTI-INF"
        stat={{ value: "15 min", label: "do zero à sobremesa" }}
        ctaLabel="Quero fazer essa sobremesa hoje"
        onCtaClick={handleButtonClick}
      />

      <PainSection />
      <AuthoritySection />
      <TransformationSection onButtonClick={handleButtonClick} />

      {/* Vídeo 2 — quebra objeção de complexidade */}
      <VideoSection
        variant="split-left"
        tag="Ciência Aplicada · Volume 2"
        headline="Cremosidade sem lactose. A ciência explica por quê."
        subtext="A gordura do caju e do abacate forma uma rede emulsificada que imita exatamente a textura do creme de leite. Por isso nossas receitas funcionam — e por isso as genéricas ficam aguadas."
        videoSrc="/sobremesas/videos/video_02.webm"
        poster="/sobremesas/gallery/cheesecake.jpg"
        caption="Proteínas + gorduras funcionais + temperatura correta = textura perfeita sem laticínios"
      />

      <RecipeShowcase />

      {/* Galeria de vídeos — VideoWall */}
      <VideoWall
        title="Veja como ficam as sobremesas na prática"
        subtitle="Textura, cremosidade e acabamento — todas funcionais e com ciência por trás."
      />

      {/* CTA principal — visitante já viu o produto antes de decidir */}
      <CTASection onButtonClick={handleButtonClick} />

      <CourseContent />
      <TagsSystem />

      {/* Vídeo 3 — eleva percepção de valor antes dos bônus */}
      <VideoSection
        variant="cinematic"
        tag="Volume 3 — Trufas & Docinhos"
        headline="Da trufa rápida ao bombom artesanal de 3 camadas."
        subtext="O mesmo volume que te ensina a fazer trufa em 20 minutos também te leva ao nível de confeitaria artesanal profissional. Você escolhe o ritmo. A ciência é a mesma."
        videoSrc="/sobremesas/videos/video_03.webm"
        poster="/sobremesas/gallery/trufa.jpg"
        caption="Trufa Belga Funcional — Cacau 70% · LC · SG · Para Vender"
        ctaLabel="Quero os 3 volumes por R$47"
        onCtaClick={handleButtonClick}
      />

      <BonusSection />
      <SocialProofSection />

      {/* Vídeo 4 — âncora emocional pré-fechamento */}
      <VideoSection
        variant="highlight"
        tag="O resultado final"
        headline="A mesa de sobremesas que você vai ter."
        subtext="Não é só sobre receita. É sobre autonomia, prazer e saúde coexistindo. Sobre servir para a família sem medo. Sobre a sobremesa deixar de ser culpa e virar celebração."
        videoSrc="/sobremesas/videos/video_04.webm"
        poster="/sobremesas/gallery/mesa.jpg"
        caption="Mesa funcional — mousse, trufas, bolo, sorvete. Tudo no ecossistema."
        ctaLabel="Quero essa mesa por R$47"
        onCtaClick={handleButtonClick}
      />

      <FAQ />
      <Guarantee />
      <FinalCTA onButtonClick={handleButtonClick} />
      <Footer />
    </div>
  );
};

export default DoceSemCulpaPage;
