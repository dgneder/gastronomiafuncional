"use client";

import React, { useEffect, useState } from "react";

// Componentes otimizados
import HeroOptimized from "@/app/components/sobremesas_premium/HeroOptimized";
import MicroSocialProof from "@/app/components/sobremesas_premium/MicroSocialProof";
import VideoShowcase from "@/app/components/sobremesas_premium/VideoShowcase";
import CTASectionOptimized from "@/app/components/sobremesas_premium/CTASectionOptimized";
import BenefitsCompact from "@/app/components/sobremesas_premium/BenefitsCompact";
import TestimonialsCarousel from "@/app/components/sobremesas_premium/TestimonialsCarousel";
import FAQOptimized from "@/app/components/sobremesas_premium/FAQOptimized";
import FinalCTAOptimized from "@/app/components/sobremesas_premium/FinalCTAOptimized";
import GuaranteeCompact from "@/app/components/sobremesas_premium/GuaranteeCompact";
import StickyCTA from "@/app/components/sobremesas_premium/StickyCTA";
import FooterSimple from "@/app/components/sobremesas_premium/FooterSimple";
import LGPD from "@/app/components/sobremesas_premium/LGPD";

import { useTracking } from "@/app/hooks/useTracking";

const MEMBERKIT_URL = "https://gastronomia-funcional.memberkit.com.br/";

const YAMPI_CHECKOUT_BASE_URL =
  process.env.NEXT_PUBLIC_YAMPI_CHECKOUT_URL ||
  "https://seguro.gastronomiafuncional.online/r/5Z58H25DEY";

function buildCheckoutUrl(baseUrl: string): string {
  if (typeof window === "undefined") return baseUrl;
  
  const currentParams = new URLSearchParams(window.location.search);
  const url = new URL(baseUrl);

  currentParams.forEach((value, key) => {
    if (!url.searchParams.has(key)) url.searchParams.set(key, value);
  });

  return url.toString();
}

export default function SobremesasPremiumLandingPage() {
  const tracking = useTracking() as {
    trackViewContent?: (name: string, id: string, value: number) => void;
    trackInitiateCheckout?: (name: string, id: string, value: number) => void;
  };
  
  const [showStickyCTA, setShowStickyCTA] = useState(false);

  useEffect(() => {
    if (tracking?.trackViewContent) {
      tracking.trackViewContent(
        "Guia de Sobremesas Funcionais - Premium",
        "guia-sobremesas-premium",
        37.0
      );
    }
  }, [tracking]);

  // Controla visibilidade do Sticky CTA
  useEffect(() => {
    const handleScroll = () => {
      const heroSection = document.getElementById("hero");
      if (heroSection) {
        const heroBottom = heroSection.getBoundingClientRect().bottom;
        setShowStickyCTA(heroBottom < 0);
      }
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleLoginClick = () => {
    window.location.href = MEMBERKIT_URL;
  };

  const scrollToCTA = () => {
    const el = document.getElementById("cta");
    if (!el) return;
    el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const goToCheckout = () => {
    if (tracking?.trackInitiateCheckout) {
      tracking.trackInitiateCheckout(
        "Guia de Sobremesas Funcionais - Premium",
        "guia-sobremesas-premium",
        37.0
      );
    }
    window.location.href = buildCheckoutUrl(YAMPI_CHECKOUT_BASE_URL);
  };

  return (
    <div className="bg-white overflow-x-hidden">
      {/* ════════════════════════════════════════════════════════════════
          BLOCO 1: CAPTURA IMEDIATA (Mobile-First)
          Objetivo: CTA visível sem scroll no mobile
      ════════════════════════════════════════════════════════════════ */}
      
      <HeroOptimized
        onButtonClick={goToCheckout}
        onLoginClick={handleLoginClick}
      />

      {/* ════════════════════════════════════════════════════════════════
          BLOCO 2: VALIDAÇÃO RÁPIDA
          Objetivo: Prova social imediata + demonstração
      ════════════════════════════════════════════════════════════════ */}
      
      <MicroSocialProof />
      
      <VideoShowcase />

      {/* ════════════════════════════════════════════════════════════════
          BLOCO 3: CTA PRINCIPAL COM URGÊNCIA
          Objetivo: Capturar usuários já decididos
      ════════════════════════════════════════════════════════════════ */}
      
      <CTASectionOptimized onButtonClick={goToCheckout} />

      {/* ════════════════════════════════════════════════════════════════
          BLOCO 4: BENEFÍCIOS + PROVA SOCIAL EXPANDIDA
          Objetivo: Convencer indecisos
      ════════════════════════════════════════════════════════════════ */}
      
      <BenefitsCompact />
      
      <TestimonialsCarousel onButtonClick={scrollToCTA} />

      {/* ════════════════════════════════════════════════════════════════
          BLOCO 5: OBJEÇÕES + FECHAMENTO
          Objetivo: Remover dúvidas finais
      ════════════════════════════════════════════════════════════════ */}
      
      <FAQOptimized />
      
      <FinalCTAOptimized onButtonClick={goToCheckout} />
      
      <GuaranteeCompact />

      {/* ════════════════════════════════════════════════════════════════
          RODAPÉ
      ════════════════════════════════════════════════════════════════ */}
      
      <FooterSimple />

      {/* ════════════════════════════════════════════════════════════════
          ELEMENTOS FLUTUANTES
      ════════════════════════════════════════════════════════════════ */}
      
      <StickyCTA 
        isVisible={showStickyCTA} 
        onButtonClick={goToCheckout} 
      />
      
      <LGPD />
    </div>
  );
}